﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TravelApp.Pages {
    public class PrivacyModel : PageModel {
        public void OnGet() {
        }
    }
}
