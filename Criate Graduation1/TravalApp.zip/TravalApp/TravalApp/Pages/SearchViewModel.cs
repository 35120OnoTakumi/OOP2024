﻿namespace TravalApp.Pages {
    internal class SearchViewModel {
        public SearchViewModel() {
        }
    }
}