using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TravalApp.Pages
{
    public class SearchModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
