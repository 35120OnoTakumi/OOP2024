﻿public class RakutenTravelSettings {
    public string? ApplicationId { get; set; }
    public string? BaseUrl { get; set; }
}
